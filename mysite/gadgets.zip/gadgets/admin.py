from django.contrib import admin

from gadgets.models import Brand, Gadget

# Register your models here.

admin.site.register(Brand)
admin.site.register(Gadget)